Ford Bike System Data Analysis 

by : Lamya'a K. Balubaid 


Dataset 

A data from A GoBike dataset from Feb 2018 trips and it has 11 columns Include: 

duration_min               
start_station_id           
start_station_name         
start_station_latitude     
start_station_longitude    
end_station_id            
end_station_name          
end_station_latitude       
end_station_longitude      
bike_id                
user_type                  
member_gender              
bike_share_for_all_trip   
               

Overview 

In the last project in NAND, I performed an exploratory investigation on data given by Ford GoBike, a bike-share system supplier, utilizing Python visualization analysis. The objective is to figure out what factors have the foremost compelling control on a bicycle sharing benefit. This benefit works USA. The bicycle-sharing benefit has picked up notoriety in major cities over the globe. They permit individuals in metropolitan regions to lease bikes for brief trips more often than not inside 30 minutes. Passage GoBike has collected a affluent sum of data. Nearly all highlights were using in the analyses.


          
               
            
               
              